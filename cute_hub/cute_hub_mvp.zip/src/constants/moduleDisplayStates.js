const ModuleDisplayStates = {MINIMIZED: 0, OPEN: 1, EXPANDED: 2};

export {ModuleDisplayStates};