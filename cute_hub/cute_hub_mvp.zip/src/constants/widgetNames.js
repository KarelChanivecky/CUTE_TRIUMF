
const WidgetNames = {
    DIAGRAM: "Fridge diagram",
    CRYOSTAT: "Cryostat",
    CALIBRATION: "Calibration",
};

export {WidgetNames};
